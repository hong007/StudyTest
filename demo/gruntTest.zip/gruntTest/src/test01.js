
// var window;
// (function(window,undefined){
//     function add(a,b){
//         var c;
//         a=a+c; 
//         return a+b;
//     }
//     add(10,100);
// })(window);

function ab(){
    // alert("1214");
}